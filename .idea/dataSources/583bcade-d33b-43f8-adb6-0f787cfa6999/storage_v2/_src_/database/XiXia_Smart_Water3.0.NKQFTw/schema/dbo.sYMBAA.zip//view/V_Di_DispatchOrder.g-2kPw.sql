CREATE VIEW [dbo].[V_Di_DispatchOrder]
AS
SELECT   Id, iWPCodeID, iWPDataID, TargetValue, OrderText, SendTime, Sender, SenderDept,
                    (SELECT   cAdminName
                     FROM      dbo.P_Admin
                     WHERE   (iAdminID = dbo.Di_DispatchOrder.Sender)) AS SenderName,
                    (SELECT   cDepName
                     FROM      dbo.P_Department
                     WHERE   (iDeptID = dbo.Di_DispatchOrder.SenderDept)) AS SenderDeptName, Receiver, ReceiverDept, ReceiveTime,
                    (SELECT   cAdminName
                     FROM      dbo.P_Admin AS P_Admin_2
                     WHERE   (iAdminID = dbo.Di_DispatchOrder.Receiver)) AS ReceiverName,
                    (SELECT   cDepName
                     FROM      dbo.P_Department AS P_Department_2
                     WHERE   (iDeptID = dbo.Di_DispatchOrder.ReceiverDept)) AS ReceiverDeptName, Executor, ExecutorDept, 
                ExecutionTime,
                    (SELECT   cAdminName
                     FROM      dbo.P_Admin AS P_Admin_1
                     WHERE   (iAdminID = dbo.Di_DispatchOrder.Executor)) AS ExecutorName,
                    (SELECT   cDepName
                     FROM      dbo.P_Department AS P_Department_1
                     WHERE   (iDeptID = dbo.Di_DispatchOrder.ExecutorDept)) AS ExecutorDeptName, Remark
FROM      dbo.Di_DispatchOrder
GO

