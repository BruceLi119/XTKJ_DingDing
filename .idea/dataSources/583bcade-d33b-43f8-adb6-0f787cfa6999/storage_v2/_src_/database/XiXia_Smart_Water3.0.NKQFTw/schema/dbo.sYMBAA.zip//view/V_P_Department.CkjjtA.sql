CREATE VIEW [dbo].[V_P_Department]
AS
SELECT     dbo.P_Department.iDeptID, dbo.P_Department.iAdminID, dbo.P_Department.cDepName, dbo.P_Department.cDepTel, dbo.P_Department.cDepEmail, 
                      dbo.P_Department.iIsLocked, dbo.P_Department.iIsAllowChangePWD, dbo.P_Admin.cAdminName, dbo.P_Department.PiDeptID
FROM         dbo.P_Department LEFT OUTER JOIN
                      dbo.P_Admin ON dbo.P_Department.iAdminID = dbo.P_Admin.iAdminID
GO

