CREATE VIEW [dbo].[V_M_MonitorPoint]
AS
SELECT     dbo.M_MonitorPoint.iMonitorPointID, dbo.M_MonitorPoint.iMonitorAreaID, dbo.M_MonitorPoint.iMonitorPonitTypeID, dbo.M_MonitorPoint.cMonitorPointName, 
                      dbo.M_MonitorPoint.iMonitorPonitOrder, dbo.M_MonitorPoint.cMonitorPointAddress, dbo.M_MonitorPoint.DataMapX, dbo.M_MonitorPoint.DataMapY, 
                      dbo.M_MonitorPoint.cMonitorPointPhoto, dbo.M_MonitorPoint.cMonitorPointIcon, dbo.M_MonitorPoint.DataFunURL, dbo.M_MonitorPoint.iMoinitorDataTableID, dbo.V_M_MonitorDataTable.FunUrl, 
                      dbo.V_M_MonitorDataTable.DataTableTypeID
FROM         dbo.M_MonitorPoint LEFT OUTER JOIN
                      dbo.V_M_MonitorDataTable ON dbo.M_MonitorPoint.iMoinitorDataTableID = dbo.V_M_MonitorDataTable.iMoinitorDataTableID
where dbo.M_MonitorPoint.MonitorPointIsDelete=0
GO

