CREATE VIEW [dbo].[V_M_MonitorTablePoint]
AS
SELECT     MT.iMonitorPointID, MT.iMoinitorDataTableID, MD.DataTableTypeID, MD.cMoinitorDataName, MD.cMoinitorDataTableName
FROM         dbo.M_MonitorTablePoint AS MT LEFT OUTER JOIN
                      dbo.M_MonitorDataTable AS MD ON MT.iMoinitorDataTableID = MD.iMoinitorDataTableID
WHERE     (MT.IsDeleted = 0)
GO

