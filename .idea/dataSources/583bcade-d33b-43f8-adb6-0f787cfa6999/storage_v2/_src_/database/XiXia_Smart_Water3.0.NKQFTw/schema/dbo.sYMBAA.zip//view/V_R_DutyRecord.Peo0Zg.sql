
CREATE VIEW [dbo].[V_R_DutyRecord]
AS
SELECT     iDutyRecordID, cMorningRecord, cAfternoonRecord, cNightRecord, cMorningWorker, cAfternoonWorker, cNightWorker, dDutyTime, dModifyTime, cRemark, DATEPART(YYYY, dDutyTime) AS dYear, 
                      DATEPART(MM, dDutyTime) AS dMonth, DATEPART(DD, dDutyTime) AS dDay, CONVERT(varchar(100), dDutyTime, 23) AS dDutyTimeYMD, CASE WHEN dateadd(hour, 8, dateadd(minute, 30, 
                      CONVERT(datetime, dDutyTime))) >= DATEADD(dd, - 1, getdate()) THEN 1 ELSE 0 END AS isEdit
FROM         dbo.R_DutyRecord

GO

