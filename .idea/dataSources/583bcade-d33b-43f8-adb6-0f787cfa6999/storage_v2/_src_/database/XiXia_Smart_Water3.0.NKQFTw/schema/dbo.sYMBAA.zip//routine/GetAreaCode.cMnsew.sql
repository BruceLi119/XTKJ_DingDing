CREATE function [dbo].[GetAreaCode]
(
@UpAreaID INT,
@RandCode VARCHAR(20)
)
RETURNS VARCHAR(100)
AS
BEGIN
DECLARE @i INT
DECLARE @j INT
declare @return varchar(100)
SET @i=1
SET @j=0

WHILE @i=1
BEGIN
declare @upcode varchar(100)
declare @topid int

declare @area1 varchar(20)
declare @area2 varchar(20)
declare @area3 varchar(20)
declare @area4 varchar(20)

declare @area1Max int
declare @area2Max int
declare @area3Max int

SET @area4=@RandCode

select @topid=PAreaID FROM DMA_Area
where AreaID=@upareaid

if @upareaid=0  
begin
--说明添加的是一级
 select @area1Max=ISNULL(MAX(id),0)+1+@j from (select SUBSTRING (DAreaCode,0,3) id from DMA_Area) a

 set @return=RIGHT('100000'+CONVERT(VARCHAR(100),@area1Max),2)+'0000000'+@area4
end
else IF @topid=0
begin
--顶级，说明添加的是二级
 select @upcode=SUBSTRING(DAreaCode,0,3) FROM DMA_Area where AreaID=@upareaid
 
 select @area2Max=ISNULL(MAX(id),0)+1+@j from (select SUBSTRING (DAreaCode,0,6) id from DMA_Area where DAreaCode LIKE @upcode+'%' and PAreaID=@upareaid) a
 
 set @return=@upcode+RIGHT('100000'+CONVERT(VARCHAR(100),@area2Max),3)+'0000'+@area4
end
else 
begin
--添加的是三级
 select @upcode=SUBSTRING(DAreaCode,0,6) FROM DMA_Area where AreaID=@upareaid

 select @area3Max=ISNULL(MAX(id),0)+1+@j from (select SUBSTRING (DAreaCode,0,10) id from DMA_Area where DAreaCode LIKE @upcode+'%' and PAreaID=@upareaid) a
 
 set @return=@upcode+RIGHT('100000'+CONVERT(VARCHAR(100),@area3Max),4)+@area4
end

SELECT @i=COUNT(1) FROM DMA_Area WHERE DAreaCode=@return
SET @j=@j+1

END

IF @return IS NULL
SET @return=''

RETURN @return

END
GO

