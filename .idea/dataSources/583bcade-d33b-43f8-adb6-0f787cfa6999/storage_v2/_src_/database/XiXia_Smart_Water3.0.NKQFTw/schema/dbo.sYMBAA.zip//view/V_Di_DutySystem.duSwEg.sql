
CREATE VIEW [dbo].[V_Di_DutySystem]
AS
SELECT   dbo.Di_DutySystem.Id, dbo.Di_DutySystem.DeptId, dbo.Di_DutySystem.OfficeName, dbo.Di_DutySystem.ShiftsCount, 
                dbo.Di_DutySystem.WorkerGroupsCount, dbo.Di_DutySystem.ShiftDutyTimeList, 
                dbo.Di_DutySystem.WorkerGroupNameList, dbo.Di_DutySystem.Remark, dbo.P_Department.cDepName, 
                dbo.Di_DutySystem.WorkerRoleIdsList, dbo.Di_DutySystem.DraftedDate, dbo.Di_DutySystem.DesignedBy, 
                dbo.Di_DutySystem.StatusCode, dbo.P_Admin.cAdminName AS DesignedByName
FROM      dbo.Di_DutySystem LEFT OUTER JOIN
                dbo.P_Department ON dbo.Di_DutySystem.DeptId = dbo.P_Department.iDeptID LEFT OUTER JOIN
                dbo.P_Admin ON dbo.Di_DutySystem.DesignedBy = dbo.P_Admin.iAdminID
GO

