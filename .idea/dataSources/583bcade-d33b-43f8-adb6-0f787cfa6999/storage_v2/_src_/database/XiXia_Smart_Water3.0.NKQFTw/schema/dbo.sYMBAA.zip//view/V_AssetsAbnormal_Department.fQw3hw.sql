CREATE VIEW dbo.V_AssetsAbnormal_Department
AS
SELECT     dbo.OT_AssetsAbnormal.*, dbo.P_Department.cDepName
FROM         dbo.OT_AssetsAbnormal INNER JOIN
                      dbo.P_Department ON dbo.OT_AssetsAbnormal.DepID = dbo.P_Department.iDeptID
GO

