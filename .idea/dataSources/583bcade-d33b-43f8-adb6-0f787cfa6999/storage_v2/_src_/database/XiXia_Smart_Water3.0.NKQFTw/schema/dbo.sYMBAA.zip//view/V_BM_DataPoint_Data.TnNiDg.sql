CREATE VIEW dbo.V_BM_DataPoint_Data
AS
SELECT     dbo.BM_MeterInfo_Data.np, dbo.BM_MeterInfo_Data.DataPointCID, dbo.BM_MeterInfo_Data.DataPointID, dbo.BM_MeterInfo_Data.iPositiveFlowRate, 
                      dbo.BM_MeterInfo_Data.iNegativeFlowRae, dbo.BM_MeterInfo_Data.iPositiveAccumulativeFlow, dbo.BM_MeterInfo_Data.iNegativeAccumulativeFlow, 
                      dbo.BM_MeterInfo_Data.iUnitTime, dbo.BM_MeterInfo_Data.ReadDate, dbo.BM_MeterInfo_Data.Created, CONVERT(varchar(100), dbo.BM_MeterInfo_Data.ReadDate, 
                      23) AS CreatedYMD, DATEPART(YEAR, dbo.BM_MeterInfo_Data.ReadDate) AS CreatedYear, DATEPART(MONTH, dbo.BM_MeterInfo_Data.ReadDate) AS CreatedMonth, 
                      DATEPART(DAY, dbo.BM_MeterInfo_Data.ReadDate) AS CreatedDay, DATEPART(HH, dbo.BM_MeterInfo_Data.ReadDate) AS Hours, dbo.BM_MeterInfo.DataPointName, 
                      dbo.BM_MeterInfo.iMeterTypeID
FROM         dbo.BM_MeterInfo_Data LEFT OUTER JOIN
                      dbo.BM_MeterInfo ON dbo.BM_MeterInfo_Data.DataPointID = dbo.BM_MeterInfo.DataPointID
GO

