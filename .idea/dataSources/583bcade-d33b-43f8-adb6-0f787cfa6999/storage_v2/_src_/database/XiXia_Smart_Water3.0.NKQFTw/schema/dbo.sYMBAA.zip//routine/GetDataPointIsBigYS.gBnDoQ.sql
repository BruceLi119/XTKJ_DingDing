CREATE FUNCTION [dbo].[GetDataPointIsBigYS]
(
@DataPointID INT,
@AreaID INT
)
RETURNS INT
AS
BEGIN
 DECLARE @Count INT
 
 SELECT @Count=COUNT(1) FROM DMA_MeterInfoBigYS WHERE DataPointID=@DataPointID --AND AreaID=@AreaID

 RETURN @Count
END
GO

