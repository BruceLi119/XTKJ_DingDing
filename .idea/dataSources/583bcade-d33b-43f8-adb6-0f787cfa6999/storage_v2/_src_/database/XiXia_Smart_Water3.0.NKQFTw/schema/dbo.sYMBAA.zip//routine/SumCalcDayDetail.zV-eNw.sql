
CREATE FUNCTION [dbo].[SumCalcDayDetail]
(
@AreaID int,
@Date datetime
)
RETURNS @T table
(
AreaID int,
DataPointID int,
DataPointName varchar(1000),
YSHH varchar(1000),
BeginTime datetime,
EndTime datetime,
ZLJ_B float,
ZLJ_E float,
ZLJ float,
FLJ_B float,
FLJ_E float,
FLJ float,
LLFX int
)
AS
BEGIN
--获取流量计信息
INSERT INTO @T(AreaID,DataPointID,DataPointName,LLFX,YSHH)
select AreaID,DataPointID,DataPointName,FlowDeriect,ISNULL(YSCode,'') from DMA_MeterInfo
where Area_DataPoint_Type=0
and AreaID in
(select AreaID FROM DMA_Area where AreaID=@AreaID OR PAreaID=@AreaID)

--获取相关读数
declare @bm table
(
DataPointID int,
ReadDate datetime,
iPositiveAccumulativeFlow float,
iNegativeAccumulativeFlow float
)

insert into @bm
select [DataPointID],[ReadDate],[iPositiveAccumulativeFlow],[iNegativeAccumulativeFlow]
FROM BM_MeterInfo_Data 
where ReadDate>=@Date AND ReadDate<DATEADD(DAY,2,@Date)
AND DataPointID in
(select DataPointID FROM @T )


UPDATE @T SET
BeginTime=b.MinDate,
EndTime=b.MaxDate
FROM @T a,(
select DataPointID,
MIN(ReadDate) MinDate,MAX(ReadDate) MaxDate
 from @bm
where CONVERT(VARCHAR(10),ReadDate,120)=CONVERT(VARCHAR(10), @Date,120)
AND DataPointID in
(select DataPointID FROM @T )
GROUP BY DataPointID,CONVERT(VARCHAR(10),ReadDate,120)
) b
WHERE a.DataPointID=b.DataPointID


UPDATE @T SET
EndTime=b.MinDate
FROM @T a,(
select DataPointID,Min(ReadDate) MinDate
 from @bm
where CONVERT(VARCHAR(10),ReadDate,120)=CONVERT(VARCHAR(10),DATEADD(DAY,1,@Date),120)
AND DataPointID in
(select DataPointID FROM @T )
GROUP BY DataPointID
) b
WHERE a.DataPointID=b.DataPointID

--DELETE FROM @T WHERE BeginTime IS NULL OR EndTime IS NULL

UPDATE @T SET
ZLJ_B=b.iPositiveAccumulativeFlow,
FLJ_B=b.iNegativeAccumulativeFlow
FROM @T a,@bm b
WHERE a.BeginTime=b.ReadDate AND a.DataPointID=b.DataPointID

UPDATE @T SET
ZLJ_E=b.iPositiveAccumulativeFlow,
FLJ_E=b.iNegativeAccumulativeFlow
FROM @T a,@bm b
WHERE a.EndTime=b.ReadDate AND a.DataPointID=b.DataPointID

UPDATE @T SET
ZLJ=ZLJ_E-ZLJ_B,
FLJ=FLJ_E-FLJ_B



RETURN
END

GO

