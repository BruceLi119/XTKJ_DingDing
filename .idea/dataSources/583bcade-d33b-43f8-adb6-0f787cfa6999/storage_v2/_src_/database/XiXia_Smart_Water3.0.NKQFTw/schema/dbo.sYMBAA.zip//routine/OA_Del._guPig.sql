-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[OA_Del]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		delete from OA_Files --借阅记录 借阅审批
		delete from OA_DossierRead --借阅记录 借阅审批
		delete from OA_trashEmain --废纸篓
		delete from OA_PerformanceCycle --考核周期
		delete from OA_EvaluatePool --查看汇总
		delete from OA_Evaluate --历史评分
		delete from OA_OutStore --出库记录
		delete from OA_Order --采购订单
		delete from VM_CLDA --车辆管理下
		delete from VM_JYGL --车辆管理下
		delete from VM_WXBY --车辆管理下
		delete from VM_YCGL --车辆管理下
END
GO

