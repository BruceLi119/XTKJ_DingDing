

-- =============================================
-- Author:		刘书杰
-- Create date: 2014-12-11
-- Description:	动态创建物理监测点数据库主表
-- =============================================
Create PROCEDURE [dbo].[DelPointTable]
	@tablename nvarchar(200)
AS
BEGIN
	declare @excPrimaryTableSql varchar(2000);
	declare @excChildTableSql varchar(2000);
	
	--删除主表
	SET @excPrimaryTableSql = 'drop table '+@tablename;
	--删除从表				
	SET @excChildTableSql = 'drop table '+@tablename+'_Data';
					
	exec(@excPrimaryTableSql);
	exec(@excChildTableSql);
END


GO

