
CREATE VIEW [dbo].[V_A_Alarm]
AS
SELECT     dbo.A_Alarm.*, dbo.A_AlarmType.TypeName, dbo.A_AlarmType.type_Desc, dbo.A_AlarmType.DataType
FROM         dbo.A_Alarm LEFT OUTER JOIN
                      dbo.A_AlarmType ON dbo.A_Alarm.AlarmTypeId = dbo.A_AlarmType.AlarmTypeId


GO

