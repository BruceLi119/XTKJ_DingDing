CREATE VIEW [dbo].[V_M_MonitorDataTable]
AS
SELECT     dbo.M_MonitorDataTable.iMoinitorDataTableID, dbo.M_MonitorDataTable.DataTableTypeID, dbo.M_MonitorDataTable.cMoinitorDataName, dbo.M_MonitorDataTable.cMoinitorDataTableName, 
                      dbo.M_MonitorDataTable_Type.FunUrl
FROM         dbo.M_MonitorDataTable LEFT OUTER JOIN
                      dbo.M_MonitorDataTable_Type ON dbo.M_MonitorDataTable.DataTableTypeID = dbo.M_MonitorDataTable_Type.DataTableTypeID
GO

