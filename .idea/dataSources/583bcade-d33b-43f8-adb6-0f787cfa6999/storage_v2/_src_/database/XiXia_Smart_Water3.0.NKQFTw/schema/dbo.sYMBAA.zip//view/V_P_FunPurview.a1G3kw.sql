CREATE VIEW [dbo].[V_P_FunPurview]
AS
SELECT     dbo.P_FunPurview.iPurviewID, dbo.P_FunPurview.iFunID, dbo.P_Function.cFunName, dbo.P_Function.cFunUrl, dbo.P_Function.cFunSmallIcon, 
                      dbo.P_Function.iFunMenuIsShow, dbo.P_Function.iFunFatherID, dbo.P_FunPurview.iPurviewType, dbo.P_Function.cFunMenuOrder, 
                      dbo.P_Function.System_Type, dbo.P_Function.cFunPosition, dbo.P_Function.cFunHeight, dbo.P_Function.cFunWidth
FROM         dbo.P_FunPurview LEFT OUTER JOIN
                      dbo.P_Function ON dbo.P_FunPurview.iFunID = dbo.P_Function.iFunID
GO

