
CREATE VIEW [dbo].[V_EQ_EQuipmentApply]
AS
SELECT     a.EAID, a.EANO, a.EADptID, a.EaReson, a.EARemark, a.EAUserID, a.EADate, a.Created, a.EAType, a.EAName, a.EAState, b.EAEID, b.EQID, 
b.EQNO, b.EQName, b.EQCID, b.DepID,a.DeptAreaID, b.LocationID, b.EQState, b.EQTypeID, 
b.EQBTypeID, b.EQSTypeID, b.ModelNO, b.EQBuyDate, b.EQUseYear, 
b.OriginalPrice, b.FactoryNO, b.FactoryName , c.cDepName AS AfterName , d.cDepName AS BeforeName
FROM         dbo.EQ_EQuipmentApply AS a LEFT OUTER JOIN
dbo.EQ_ApplyEquipment AS b ON a.EAID = b.EAID LEFT OUTER JOIN
dbo.P_Department AS c ON a.EADptID = c.iDeptID LEFT OUTER JOIN
dbo.P_Department AS d ON b.DepID = d.iDeptID

GO

