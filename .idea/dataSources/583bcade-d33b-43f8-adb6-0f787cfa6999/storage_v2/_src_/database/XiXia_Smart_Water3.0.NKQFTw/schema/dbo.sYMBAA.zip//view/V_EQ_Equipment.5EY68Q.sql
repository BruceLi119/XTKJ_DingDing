
CREATE VIEW [dbo].[V_EQ_Equipment]
AS
SELECT     a.EQID, a.EQNO, a.EQName, a.EQCID, a.DepID,a.DeptAreaID, a.LocationID, a.EQState, a.EQTypeID, a.EQBTypeID, a.EQSTypeID, a.ModelNO, a.EQBuyDate, a.EQUseYear, 
                      a.OriginalPrice, a.FactoryNO, a.FactoryName, a.UserID, a.Created,a.EQGuiGe, b.CatName AS ETName, c.cDepName, d.CatName AS BCatName, e.CatName AS SCatName
FROM         dbo.EQ_Equipment AS a LEFT OUTER JOIN
                      dbo.EQ_CateGory AS b ON a.EQTypeID = b.DCID LEFT OUTER JOIN
                      dbo.P_Department AS c ON c.iDeptID = a.DepID LEFT OUTER JOIN
                      dbo.EQ_CateGory AS d ON a.EQBTypeID = d.DCID LEFT OUTER JOIN
                      dbo.EQ_CateGory AS e ON a.EQSTypeID = e.DCID

GO

