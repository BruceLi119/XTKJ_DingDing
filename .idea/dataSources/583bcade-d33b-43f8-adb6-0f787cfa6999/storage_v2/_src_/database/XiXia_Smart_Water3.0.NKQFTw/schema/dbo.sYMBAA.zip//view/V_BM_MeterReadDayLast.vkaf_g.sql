

CREATE VIEW [dbo].[V_BM_MeterReadDayLast]
AS
SELECT     DataPointID, iMonitorDataTableID, MeterAddr, DATEPART(DD, ReadDate) AS ReadDay, CAST(CONVERT(varchar(10), ReadDate, 23) AS datetime) AS ReadDate, 
                      MIN(LastHourPositiveNumber) AS YesterdayPositiveNumber, MIN(LastHourNegativeNumber) AS LastHourNegativeNumber, MAX(ReadPositiveNumber) 
                      AS ReadPositiveNumber, MAX(ReadNegativeNumber) AS ReadNegativeNumber, SUM(CurrentTraffic) AS CurrentTraffic
FROM         dbo.BM_MeterReadHourLast
GROUP BY DataPointID, iMonitorDataTableID, MeterAddr, DATEPART(DD, ReadDate), CONVERT(varchar(10), ReadDate, 23)

GO

