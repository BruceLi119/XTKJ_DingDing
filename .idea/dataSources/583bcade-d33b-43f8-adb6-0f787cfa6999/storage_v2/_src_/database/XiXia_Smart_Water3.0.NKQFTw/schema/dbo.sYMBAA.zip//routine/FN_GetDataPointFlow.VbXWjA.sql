CREATE FUNCTION [dbo].[FN_GetDataPointFlow]
(
@SDate DATETIME,
@EDate DATETIME
)
RETURNS @T TABLE
(
DataPointID INT,
DataPointName VARCHAR(1000),
AreaID INT,
AreaName VARCHAR(1000),
Flow INT,
SumFlow Float,
SumPFlow Float,
SumNFlow Float
)
AS
BEGIN
INSERT INTO @T
SELECT MI.DataPointID,
ISNULL((SELECT BMI.DataPointName FROM BM_MeterInfo BMI WHERE BMI.DataPointID=MI.DataPointID),MI.DataPointName),
Area.AreaID,Area.cMonitorAreaName,MI.FlowDeriect,0,0,0 
FROM DMA_MeterInfo MI
INNER JOIN DMA_Area Area ON Area.AreaID=MI.AreaID
WHERE MI.Area_DataPoint_Type=0

UPDATE @T SET
SumPFlow=ISNULL(b.PFlow,0),
SumNFlow=ISNULL(b.NFlow,0)
FROM @T a,
(
SELECT 
DataPointID,
SUM(PCumulativeFlow) PFlow,
SUM(NCumulativeFlow) NFlow
FROM DMA_FlowStaticHour 
WHERE CaclDate BETWEEN @SDate AND @EDate
GROUP BY DataPointID
) b
WHERE a.DataPointID=b.DataPointID

UPDATE @T SET
SumFlow=ROUND(SumPFlow,2)
WHERE Flow=1

UPDATE @T SET
SumFlow=ROUND(SumNFlow,2)
WHERE Flow=2

RETURN
END
GO

