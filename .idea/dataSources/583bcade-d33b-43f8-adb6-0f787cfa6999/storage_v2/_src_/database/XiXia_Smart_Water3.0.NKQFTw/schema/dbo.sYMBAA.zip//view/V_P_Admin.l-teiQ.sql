CREATE VIEW dbo.V_P_Admin
AS
SELECT     dbo.P_Admin.iAdminID, dbo.P_Admin.iDeptID, dbo.P_Admin.iRoleID, dbo.P_Admin.cAdminName, dbo.P_Admin.cAdminSex, dbo.P_Admin.cAdminPassWord, 
                      dbo.P_Admin.cAdminTel, dbo.P_Admin.cAdminEmail, dbo.P_Admin.iIsLocked, dbo.P_Admin.dExpireDate, dbo.P_Admin.iIsAllowChangePWD, 
                      dbo.P_Admin.cLastLoginIP, dbo.P_Admin.dLastLoginTime, dbo.P_Admin.dLastLogoutTime, dbo.P_Admin.iLoginTimes, dbo.P_Admin.cTitlePic, dbo.P_Admin.iSkinID, 
                      dbo.P_Department.cDepName, dbo.P_Role.cRoleName, dbo.P_Admin.CJobNumber, dbo.P_Admin.JueSeID, dbo.P_Admin.IsDelete, dbo.P_Admin.IsDutyAdministrator, 
                      dbo.P_Admin.IsSecCheckGis, dbo.P_Admin.YingShouID, dbo.P_Admin.HostIP, dbo.P_Admin.AllPinyin, dbo.P_Admin.[Level], dbo.P_Admin.IsNumOne, 
                      dbo.P_Admin.Smid, dbo.P_Admin.LoginTicket
FROM         dbo.P_Admin LEFT OUTER JOIN
                      dbo.P_Department ON dbo.P_Admin.iDeptID = dbo.P_Department.iDeptID INNER JOIN
                      dbo.P_Role ON dbo.P_Admin.iRoleID = dbo.P_Role.iRoleID
GO

