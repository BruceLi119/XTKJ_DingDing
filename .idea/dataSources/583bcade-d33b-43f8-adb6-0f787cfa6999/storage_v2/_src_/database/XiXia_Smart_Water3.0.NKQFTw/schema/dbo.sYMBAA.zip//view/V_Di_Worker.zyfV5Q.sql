CREATE VIEW [dbo].[V_Di_Worker]
AS
SELECT   iAdminID AS Id, iDeptID, iRoleID, cDepName, cRoleName, cAdminName AS Name, cAdminTel AS Telphone, 
                cAdminEmail AS Email, iIsLocked
FROM      dbo.V_P_Admin
GO

