CREATE VIEW dbo.V_DataPoint_Data_RT
AS
SELECT     a.DDRID, a.DataPointID, a.iMoinitorDataTableID, a.iDKID, a.DataFieldCName, a.DataFieldEName, a.iIsAlarm, a.iISGis, a.iISDisplay, a.iISEchart, a.iISCurrentSateChart, 
                      a.ISOftenData, a.iValue, a.ReadTime, b.iDataType, b.iDKName, b.iDKUnit, a.OrderNO, a.DataFieldAlias
FROM         dbo.DataPoint_Data_RT AS a LEFT OUTER JOIN
                      dbo.M_DataKind AS b ON b.iDKID = a.iDKID
GO

