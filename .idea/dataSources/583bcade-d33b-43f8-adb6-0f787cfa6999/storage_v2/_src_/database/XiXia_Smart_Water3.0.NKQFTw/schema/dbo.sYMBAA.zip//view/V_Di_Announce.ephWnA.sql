CREATE VIEW [dbo].[V_Di_Announce]
AS
SELECT     dbo.Di_Announce.ANID, dbo.Di_Announce.AnTitle, dbo.Di_Announce.AnContent, dbo.Di_Announce.AnSendDepNo, dbo.Di_Announce.AnSendPerNo, dbo.Di_Announce.AnRecDep, 
                      dbo.Di_Announce.AnRecPer, dbo.Di_Announce.ISSend, dbo.Di_Announce.AnSendDate, dbo.Di_Announce.Created, dbo.P_Department.cDepName, dbo.P_Admin.cAdminName, 
                      dbo.Di_Announce.IsDelete, dbo.Di_Announce.DValidity
FROM         dbo.Di_Announce LEFT OUTER JOIN
                      dbo.P_Admin ON dbo.Di_Announce.AnSendPerNo = dbo.P_Admin.iAdminID LEFT OUTER JOIN
                      dbo.P_Department ON dbo.Di_Announce.AnSendDepNo = dbo.P_Department.iDeptID
GO

