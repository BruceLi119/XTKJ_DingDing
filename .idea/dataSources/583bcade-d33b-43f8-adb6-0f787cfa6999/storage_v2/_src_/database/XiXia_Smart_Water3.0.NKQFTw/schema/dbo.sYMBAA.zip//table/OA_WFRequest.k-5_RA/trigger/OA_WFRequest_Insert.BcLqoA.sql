create trigger [dbo].[OA_WFRequest_Insert] on [dbo].[OA_WFRequest] instead of insert 
as  
begin
declare 
@Title nvarchar(100),
@Name nvarchar(50),
@Startdate datetime,
@Enddate datetime,
@Hours int,
@Reason nvarchar(200),
@RType uniqueidentifier,
@CreateTime datetime

select @Title= Title,@Name=Name, @Startdate = Startdate,@Enddate = Enddate, @Reason =Reason, @RType =RType from inserted;

set @Hours = DATEDIFF(hour,@Startdate,@Enddate);
set @CreateTime = GETDATE();

insert into OA_WFRequest(Title, Name,Startdate,Enddate,[Hours],Reason,RType,CreateTime)
values (@Title, @Name,@Startdate,@Enddate,@Hours,@Reason,@RType,@CreateTime);

end
GO

