

CREATE VIEW [dbo].[V_P_Role]
AS
SELECT     iRoleID, cRoleName, iIsAllowChangePWD, iIsLocked, cRoleExplain
FROM         dbo.p_Role


GO

