CREATE function [dbo].[GetAreaSumUserFlow]
(
@AreaID INT,
@BeginDate DATETIME,
@EndDate DATETIME
)
RETURNS FLOAT
AS
BEGIN
DECLARE @SumNum FLOAT

DECLARE @AreaIDList VARCHAR(MAX)
SET @AreaIDList='0'

DECLARE @AreaLev INT
SET @AreaLev=0

SELECT @AreaLev=Hier FROM DMA_Param WHERE AreaID=@AreaID

IF @AreaLev=1
SELECT  @AreaIDList=@AreaIDList+CONVERT(VARCHAR(MAX),AreaID)+',' FROM DMA_Area WHERE AreaID=@AreaID OR PAreaID=@AreaID
ELSE IF @AreaLev=2
SET @AreaIDList=CONVERT(VARCHAR(MAX),@AreaID)

SELECT @SumNum=SUM(ISNULL(Num,0)) FROM YS_Billinfo 
WHERE DATEDIFF(MM,ReadDate,@BeginDate)<=0  and DATEDIFF(MM,ReadDate,@EndDate)>=0 
AND USERINFOID IN 
(
 SELECT CID FROM YS_CustomerInfo
 WHERE USERINFOID IN
 (
  SELECT SMeterInfoID 
  FROM DMA_YS_UserMeterInfo 
  WHERE AreaID IN 
  (
  SELECT  * FROM dbo.f_split(@AreaIDList,',')
  )
 )
)
IF @SumNum IS NULL
SET @SumNum=0

RETURN @SumNum
END
GO

