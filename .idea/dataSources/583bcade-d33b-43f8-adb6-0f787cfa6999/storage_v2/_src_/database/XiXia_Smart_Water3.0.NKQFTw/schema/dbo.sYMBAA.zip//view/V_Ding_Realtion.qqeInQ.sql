CREATE VIEW dbo.V_Ding_Realtion
AS
SELECT   RelationId, DingLeaderUserId, DingUnionId, DingActive, DingOrderInDepts, DingIsAdmin, DingIsBoss, 
                DingIsLeaderInDepts, DingDepartment, DingPosition, DingAvatar, DingJobNumber, DingIsSenior, DingDeptId, 
                DingUserId, DingUserName, SmartDeptId, SmartUserId, SmartUserName, SyncTime
FROM      LeaRunFramework_Base_2016.dbo.Ding_Relation
GO

