CREATE FUNCTION [dbo].[F_GetDmaMonthReport]
(
@areaid int,
@startDate varchar(100),
@endDate varchar(100),
@isSum int  --1添加合计列
)
RETURNS @T table
(
Year_Month varchar(10) default '',
Years INT default 0,
Months INT default 0,
AreaID INT  default 0,
AreaName varchar(100) default '',
SumFlow float default 0,
FlowIn float default 0,
FlowOut float default 0,
SumLoss float default 0,
YS_Count float default 0,
YS_Real float default 0,
YS_Loss float default 0,
YS_WaterVol float default 0,
CXC VARCHAR(10) default ''
)
AS
BEGIN
--日期处理
IF LEN(@startDate)=0
SET @startDate='1900-01-01'

IF LEN(@endDate)=0
SET @endDate=DATEADD(DAY,1,GETDATE())

DECLARE @lev int 
DECLARE @ids varchar(max)
SET @ids =''
declare @split_AreaID varchar(max)
SET @split_AreaID=''

declare @isCalcDirect int --1计算直管用户

select @lev=hier FROM DMA_Param WHERE AreaID=@areaid


IF @lev=1 
begin
    set @isCalcDirect=1
 SELECT @ids=@ids+convert(varchar(max),AreaID)+',' 
 FROM DMA_Area 
 where PAreaID in(SELECT AreaID FROM DMA_Area where PAreaID=@areaid)
 
 SELECT @split_AreaID=@split_AreaID+CONVERT(VARCHAR(1000),AreaID)+',' 
 FROM DMA_Area WHERE PAreaID=@areaid
end

IF @lev=2
BEGIN
 set @isCalcDirect=1
 SELECT @split_AreaID=@split_AreaID+CONVERT(VARCHAR(1000),AreaID)+',' 
 FROM DMA_Area WHERE PAreaID=@areaid 
END

IF @lev=3
BEGIN
 set @isCalcDirect=0
 SET @split_AreaID=CONVERT(VARCHAR(1000),@areaid) 
END

declare @flow table
(
iYear int default 0,
iMonth int default 0,
AreaID int default 0,
Sum_SiteFlow float default 0,
Sum_SiteFlowIN float default 0,
Sum_SiteFlowOUT float default 0,
yscount int default 0
)

INSERT INTO @flow
SELECT  iYear,iMonth, AreaID,
  SUM(ISNULL(Sum_SiteFlow,0)),
  SUM(ISNULL(Sum_SiteFlowIN,0)),
  SUM(ISNULL(Sum_SiteFlowOUT,0)),
  (SELECT COUNT(1) FROM DMA_YS_UserMeterInfo  WHERE AreaID=DMA_Sum_MonthClacVal.AreaID AND (YEAR(ISNULL(AddDate,'1900-1-1'))<DMA_Sum_MonthClacVal.iYear OR( DMA_Sum_MonthClacVal.iYear=YEAR(ISNULL(AddDate,'1900-1-1')) AND DMA_Sum_MonthClacVal.iMonth>=MONTH(ISNULL(AddDate,'1900-1-1')))))
FROM DMA_Sum_MonthClacVal
WHERE (iYear>YEAR(@startDate) OR( iYear=YEAR(@startDate) AND iMonth>=MONTH(@startDate)))
AND (iYear<YEAR(@endDate) OR( iYear=YEAR(@endDate) AND iMonth<=MONTH(@endDate)))
AND AreaID IN (SELECT * FROM DBO.f_split(@split_AreaID,',') UNION ALL SELECT * FROM DBO.f_split(@ids,','))
GROUP BY AreaID,iYear,iMonth
ORDER BY AreaID,iYear,iMonth


declare @ys table
(
iYear int default 0,
iMonth int default 0,
AreaID int default 0,
NUM int default 0,
WaterVol float default 0
)

IF @lev=1
begin 
 INSERT INTO @ys
 SELECT * FROM (
 select YSVOL.WaterVolYear iYear,YSVOL.WaterVolMonth iMonth,area.PAreaID AreaID, COUNT(1) NUM, SUM(YSVOL.CalcWaterVol) WaterVol
 from  DMA_YS_UserMeterInfo YSUSER
 left join YS_WaterVOL YSVOL  on YSUSER.SMeterInfoID = YSVOL.USERINFOID
 LEFT JOIN DMA_Area area on area.AreaID=YSUSER.AreaID
 where YSUSER.AreaID IN (SELECT * from dbo.f_split(@ids,','))  and
 (YSVOL.WaterVolYear>YEAR(@startDate) OR( YSVOL.WaterVolYear=YEAR(@startDate) AND YSVOL.WaterVolMonth>=MONTH(@startDate)))
 AND (YSVOL.WaterVolYear<YEAR(@endDate) OR( YSVOL.WaterVolYear=YEAR(@endDate) AND YSVOL.WaterVolMonth<=MONTH(@endDate))) 
 group by  area.PAreaID,YSVOL.WaterVolYear,YSVOL.WaterVolMonth
 UNION ALL
 select YSVOL.WaterVolYear iYear,YSVOL.WaterVolMonth iMonth, YSUSER.AreaID, COUNT(1) NUM, SUM(YSVOL.CalcWaterVol) WaterVol
 from  DMA_YS_UserMeterInfo YSUSER
 left join YS_WaterVOL YSVOL  
 on YSUSER.SMeterInfoID = YSVOL.USERINFOID
 where YSUSER.AreaID IN (SELECT * from dbo.f_split(@split_AreaID,','))  and
 (YSVOL.WaterVolYear>YEAR(@startDate) OR( YSVOL.WaterVolYear=YEAR(@startDate) AND YSVOL.WaterVolMonth>=MONTH(@startDate)))
 AND (YSVOL.WaterVolYear<YEAR(@endDate) OR( YSVOL.WaterVolYear=YEAR(@endDate) AND YSVOL.WaterVolMonth<=MONTH(@endDate))) 
 group by  YSUSER.AreaID,YSVOL.WaterVolYear,YSVOL.WaterVolMonth
 )aa
end
else
begin
 INSERT INTO @ys
 select YSVOL.WaterVolYear iYear,YSVOL.WaterVolMonth iMonth, YSUSER.AreaID, COUNT(1) NUM, SUM(YSVOL.CalcWaterVol) WaterVol
 from  DMA_YS_UserMeterInfo YSUSER
 left join YS_WaterVOL YSVOL  
 on YSUSER.SMeterInfoID = YSVOL.USERINFOID
 where  YSUSER.AreaID IN (SELECT * from dbo.f_split(@split_AreaID,','))  and
 (YSVOL.WaterVolYear>YEAR(@startDate) OR( YSVOL.WaterVolYear=YEAR(@startDate) AND YSVOL.WaterVolMonth>=MONTH(@startDate)))
 AND (YSVOL.WaterVolYear<YEAR(@endDate) OR( YSVOL.WaterVolYear=YEAR(@endDate) AND YSVOL.WaterVolMonth<=MONTH(@endDate))) 
 group by  YSUSER.AreaID,YSVOL.WaterVolYear,YSVOL.WaterVolMonth
end


INSERT INTO @T(Years,Months,AreaID)
SELECT  * FROM
(
SELECT iYear,iMonth,AreaID FROM @flow WHERE AreaID IN(SELECT * FROM DBO.f_split(@split_AreaID,','))
UNION
SELECT iYear,iMonth,AreaID FROM @ys
) a


--更新日期格式
UPDATE @T SET
AreaName=b.cMonitorAreaName
FROM @T a,DMA_Area b
WHERE a.AreaID=b.AreaID

--更新管网流量
UPDATE @T SET 
SumFlow=b.Sum_SiteFlow,
FlowIn=b.Sum_SiteFlowIN,
FlowOut=b.Sum_SiteFlowOUT,
YS_Count=b.yscount
FROM @T a,@flow b
WHERE a.Years=b.iYear AND a.Months=b.iMonth AND a.AreaID=b.AreaID


UPDATE @T SET 
SumFlow=SumFlow+b.Sum_SiteFlow,
FlowIn=FlowIn+b.Sum_SiteFlowIN,
FlowOut=FlowOut+b.Sum_SiteFlowOUT,
YS_Count=YS_Count+b.yscount
FROM @T a,
(
SELECT b.PAreaID AreaID,a.iYear,a.iMonth,
SUM(a.Sum_SiteFlow)  Sum_SiteFlow,
SUM(a.Sum_SiteFlowIN)  Sum_SiteFlowIN,
SUM(a.Sum_SiteFlowOUT)  Sum_SiteFlowOUT,
SUM(a.yscount)  yscount
FROM @flow a
LEFT JOIN DMA_Area b ON a.AreaID=b.AreaID
GROUP BY b.PAreaID,a.iYear,a.iMonth
) b
WHERE a.Years=b.iYear AND a.Months=b.iMonth AND a.AreaID=b.AreaID


UPDATE @T SET 
YS_Real=ISNULL((SELECT SUM(NUM) FROM @ys WHERE iYear=[@T].Years AND iMonth=[@T].Months AND AreaID=[@T].AreaID),0),
YS_WaterVol=ISNULL((SELECT SUM(WaterVol) FROM @ys WHERE iYear=[@T].Years AND iMonth=[@T].Months AND AreaID=[@T].AreaID),0)


 IF @isSum*1>0 
  BEGIN
   INSERT INTO @T (AreaID,AreaName,SumFlow,FlowIn,FlowOut,SumLoss,YS_Count,YS_Real,YS_Loss,YS_WaterVol)
   SELECT 99999997,
   CASE WHEN @isCalcDirect*1 >0 THEN '小计' ELSE'合计' END,
   SUM(SumFlow),
   SUM(FlowIn),
   SUM(FlowOut),
   SUM(SumLoss),
   SUM(YS_Count),
   SUM(YS_Real),
   SUM(YS_Loss),
   SUM(YS_WaterVol)
   FROM @T 
  END

--计算直管用户
IF @isCalcDirect*1 > 0
 BEGIN
  INSERT INTO @T(AreaID,AreaName,YS_Count,YS_Real,YS_WaterVol)
  
  SELECT 99999998,AreaName,SUM (YS_Count ),SUM (YS_Real ),SUM (YS_WaterVol)
  FROM(
   SELECT DISTINCT
   a.AreaID ,'直管用户' AreaName
   ,(SELECT COUNT(1) FROM  DMA_YS_UserMeterInfo WHERE  AreaID=a.AreaID  AND DATEDIFF(MM, ISNULL(AddDate,'1900-1-1'),@endDate) >=0 ) YS_Count
   ,(SELECT COUNT(1) FROM YS_WaterVOL b WHERE b.USERINFOID=a.SMeterInfoID AND b.WaterVolYear=YEAR(@startDate) AND b.WaterVolMonth=MONTH(@startDate)) YS_Real
   , ISNULL((SELECT SUM(ISNULL(b.CalcWaterVol,0)) FROM YS_WaterVOL b WHERE b.USERINFOID=a.SMeterInfoID AND b.WaterVolYear=YEAR(@startDate) AND b.WaterVolMonth=MONTH(@startDate)),0) YS_WaterVol
   from DMA_YS_UserMeterInfo a
   WHERE a.AreaID=@AreaID
  ) BB
  GROUP BY BB.AreaName     
       
  INSERT INTO @T(AreaID,AreaName,YS_Real,YS_WaterVol,YS_Count,SumFlow,FlowIn,FlowOut,SumLoss)
  SELECT 99999999, '合计' ,SUM(YS_Real),SUM(YS_WaterVol),SUM(YS_Count),SUM(SumFlow),SUM(FlowIn),SUM(FlowOut),SUM(SumLoss)
  FROM  @T
  WHERE AreaID>=99999997
        
 END
 
 
UPDATE @T SET
Year_Month=CASE WHEN Years>0 AND Months>0 THEN CONVERT(VARCHAR(10),Years)+'-'+CONVERT(VARCHAR(10),Months) ELSE '' END,
YS_Loss= YS_Count-YS_Real,
SumLoss= CASE WHEN AreaID=99999998 THEN 0 ELSE  SumFlow-YS_WaterVOL END




UPDATE @T SET
CXC=CASE WHEN SumFlow<> 0 THEN CONVERT(varchar(100),ROUND(SumLoss*1.0/SumFlow*1.0,4)*100)+'%' 
      WHEN SumLoss<>0 AND SumFlow<=0 THEN   '-100%'    ELSE '' END
WHERE   AreaID<>99999998    
      
RETURN
END

GO

