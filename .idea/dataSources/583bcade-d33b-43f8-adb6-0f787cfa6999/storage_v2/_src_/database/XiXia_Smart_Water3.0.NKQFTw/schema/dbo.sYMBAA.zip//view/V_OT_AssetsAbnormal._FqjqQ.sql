

CREATE VIEW [dbo].[V_OT_AssetsAbnormal]
AS
SELECT     a.EFAID, a.OTID, a.DepID, a.LocationID, a.OTTypeID, a.OTBTypeID, a.OTSTypeID, a.OTName, a.OTNO, a.OTContent, a.OTABMaintenanceDate, a.OTABUserID, 
                      a.OTABUserName, a.OTABTime, a.OTAAssignUserID, a.AssignTime, a.PlanFinishTime, a.OTState, a.OTMaintenanceUser, a.OTFinishTime, a.IsStart, 
                      b.cDepName, b.BCatName AS BCatName, b.SCatName AS SCatName, b.CatName 
FROM         dbo.OT_AssetsAbnormal AS a LEFT OUTER JOIN
                      dbo.V_OT_Assets AS b ON b.OTID = a.OTID


GO

