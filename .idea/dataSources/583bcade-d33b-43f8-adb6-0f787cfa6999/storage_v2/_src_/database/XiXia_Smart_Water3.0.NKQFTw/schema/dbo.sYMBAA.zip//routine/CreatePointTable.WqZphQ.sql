-- =============================================
-- Author:		刘书杰
-- Create date: 2014-12-11
-- Description:	动态创建物理监测点数据库主表
-- =============================================
CREATE PROCEDURE [dbo].[CreatePointTable]
	@tablename nvarchar(200)
AS
BEGIN
	declare @excPrimaryTableSql varchar(2000);
	declare @excChildTableSql varchar(2000);
	--创建主表
	SET @excPrimaryTableSql = '
					create table '+@tablename+' (					
					   DataPointID          int                  identity(1, 1),
					   DataPointName        nvarchar(100)        null,
					   iMonitorPointID      int                  null,
					   iMonitorDataTable_TypeID int                  null,
					   iMonitorDataTableID  int                  null,
					   RTUCodeValue         nvarchar(50)         null,
					   DataOrder            int                  null,
					   DataMapX             float                null,
					   DataMapY             float                null,
					   DataIcon             nvarchar(100)        null,
					   DataFunURL           nvarchar(Max)        null,
					   DataPointIsDelete    bit                  null,
					   ModifyDate           datetime             null,
					   Created              datetime             null,
					   iAdminID             int                  null,
					   cAdminName           nvarchar(50)         null,
					   constraint PK_'+@tablename+' primary key (DataPointID)
					)';
					
				SET @excChildTableSql = '
					create table '+@tablename+'_Data (
					   DataPointCID                  int                  identity,
					   DataPointID          int                  null,
					   Created              datetime             null,
					   ReadDate             datetime             null,
					   constraint PK_'+@tablename+'_Data primary key (DataPointCID)
					)';
					
							exec(@excPrimaryTableSql);
		exec(@excChildTableSql);
END
GO

