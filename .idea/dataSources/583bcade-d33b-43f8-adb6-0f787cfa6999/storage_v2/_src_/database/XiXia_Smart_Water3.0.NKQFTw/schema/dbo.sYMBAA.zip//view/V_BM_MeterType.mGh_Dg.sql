
CREATE VIEW [dbo].[V_BM_MeterType]
AS
SELECT     dbo.BM_MeterFactory.cMeterFactoryName, dbo.BM_MeterType.*
FROM         dbo.BM_MeterType LEFT OUTER JOIN
                      dbo.BM_MeterFactory ON dbo.BM_MeterType.iMeterFactoryID = dbo.BM_MeterFactory.iMeterFactoryID

GO

