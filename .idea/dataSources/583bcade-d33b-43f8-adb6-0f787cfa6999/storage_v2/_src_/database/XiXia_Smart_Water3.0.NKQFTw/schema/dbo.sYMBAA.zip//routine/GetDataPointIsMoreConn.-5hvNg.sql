CREATE function [dbo].[GetDataPointIsMoreConn]
(
@DataPointID INT,
@AreaID INT
)
RETURNS INT
AS
BEGIN
	DECLARE @Count INT 
	DECLARE @T TABLE
	(
	AreaHier INT
	)
	INSERT INTO @T
	SELECT COUNT(P.Hier)
	FROM DMA_MeterInfo M
	INNER JOIN DMA_Param P ON P.AreaID=M.AreaID
	WHERE Area_DataPoint_Type=0 AND DataPointID=@DataPointID
	GROUP BY P.Hier
	
	SELECT @Count=COUNT(1) FROM @T
	
	IF @Count>1
		SET @Count=1
	ELSE
		SET @Count=0

	RETURN @Count
END
GO

