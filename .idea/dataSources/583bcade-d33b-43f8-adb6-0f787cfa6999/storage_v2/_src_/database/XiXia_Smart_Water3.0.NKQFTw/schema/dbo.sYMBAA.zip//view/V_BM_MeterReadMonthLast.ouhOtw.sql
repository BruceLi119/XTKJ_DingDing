CREATE VIEW [dbo].[V_BM_MeterReadMonthLast]
AS
SELECT     DataPointID, iMonitorDataTableID, MeterAddr, DATEPART(MONTH, ReadDate) AS ReadMonth, CAST(CONVERT(varchar(7), ReadDate, 23) + '-01' AS datetime) 
                      AS ReadDate, MIN(LastHourPositiveNumber) AS LastMonthPositiveNumber, MIN(LastHourNegativeNumber) AS LastMonthNegativeNumber, 
                      MAX(ReadPositiveNumber) AS ReadPositiveNumber, MAX(ReadNegativeNumber) AS ReadNegativeNumber, SUM(CurrentTraffic) AS CurrentTraffic
FROM         dbo.BM_MeterReadHourLast
GROUP BY DataPointID, iMonitorDataTableID, MeterAddr, DATEPART(MONTH, ReadDate), CONVERT(varchar(7), ReadDate, 23)

GO

