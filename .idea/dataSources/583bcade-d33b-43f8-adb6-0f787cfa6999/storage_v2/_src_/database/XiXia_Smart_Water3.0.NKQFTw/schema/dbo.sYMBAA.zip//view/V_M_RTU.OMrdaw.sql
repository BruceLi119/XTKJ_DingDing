CREATE VIEW dbo.V_M_RTU
AS
SELECT     dbo.M_MonitorPoint.cMonitorPointName, dbo.M_MonitorArea.cMonitorAreaName, dbo.M_RTU.RTUID, dbo.M_RTU.RTUName, dbo.M_RTU.RTUtAddr, 
                      dbo.M_RTU.RTUCodeValue, dbo.M_RTU.iMonitorPointID, dbo.M_RTU.InstallBillNo, dbo.M_RTU.SimCode, dbo.M_RTU.NetAddress, dbo.M_RTU.SmsCenterNumber, 
                      dbo.M_RTU.SysConterNumber, dbo.M_RTU.PortNO, dbo.M_RTU.BaudRate, dbo.M_RTU.IsDynamicDNS, dbo.M_RTU.DNS, dbo.M_RTU.ConnectionInterval, 
                      dbo.M_RTU.SystemKey, dbo.M_RTU.UndervoltageAlarmValue, dbo.M_RTU.Voltage, dbo.M_RTU.Temperature, dbo.M_RTU.IsOnlie, dbo.M_RTU.cHardwareVersion, 
                      dbo.M_RTU.cSoftwareVersion, dbo.M_RTU.IsDelete, dbo.M_RTU.Installer, dbo.M_RTU.InstalledDate, dbo.M_RTU.InstallPosition, dbo.M_RTU.Description, 
                      dbo.M_RTU.ReturnCount, dbo.M_MonitorArea.iMonitorAreaID
FROM         dbo.M_MonitorArea RIGHT OUTER JOIN
                      dbo.M_MonitorPoint ON dbo.M_MonitorArea.iMonitorAreaID = dbo.M_MonitorPoint.iMonitorAreaID RIGHT OUTER JOIN
                      dbo.M_RTU ON dbo.M_MonitorPoint.iMonitorPointID = dbo.M_RTU.iMonitorPointID
WHERE     (dbo.M_RTU.IsDelete <> 1)
GO

