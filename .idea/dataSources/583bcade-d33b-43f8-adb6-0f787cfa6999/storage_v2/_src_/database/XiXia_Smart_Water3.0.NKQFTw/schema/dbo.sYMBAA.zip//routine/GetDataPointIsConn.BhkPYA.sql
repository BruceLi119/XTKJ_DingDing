CREATE FUNCTION [dbo].[GetDataPointIsConn]
(
@DataPointID INT,
@AreaID INT
)
RETURNS INT
AS
BEGIN
 DECLARE @Count INT
 
 SELECT @Count=COUNT(1) FROM DMA_MeterInfo WHERE Area_DataPoint_Type=0 AND DataPointID=@DataPointID --AND AreaID=@AreaID

 RETURN @Count
END
GO

