CREATE VIEW dbo.V_Di_Calender
AS
SELECT WWID, '' AS iFlushID, GCMC, '' AS cProjectName, SQKSSJ AS b1, SQJZSJ AS e1, 
      PZKSSJ AS b2, PZJZSJ AS e2, SJKSSJ AS b3, SJJZSJ AS e3, 
      CASE WHEN SJJZSJ IS NOT NULL THEN 3 WHEN PZJZSJ IS NOT NULL 
      THEN 2 WHEN SQJZSJ IS NOT NULL THEN 1 ELSE 0 END AS TypeNum, SQQFR, 
      PZR
FROM Di_WithoutWater
UNION ALL
SELECT '' AS WWID, iFlushID, '' AS GCMC, cProjectName, dApplyBegin AS b1, 
      dApplyEnd AS e1, dAuditBegin AS b2, dAuditEnd AS e2, dActualBegin AS b3, 
      dActualEnd AS e3, CASE WHEN fActualTime IS NOT NULL OR
      fActualTime != 0 THEN 6 WHEN fAuditTime IS NOT NULL OR
      fAuditTime != 0 THEN 5 WHEN fApplyTime IS NOT NULL OR
      fApplyTime != 0 THEN 4 ELSE 0 END AS TypeNum, cApplicant, cAuditor
FROM Di_FlushInfo
GO

