
CREATE FUNCTION [dbo].[F_GetWaterSupplyAnalysis]
(
 @Date datetime
)
RETURNS @T TABLE
(
rows_No int default 0,
AreaID int default 0,
UpID int default 0,
TopID int default 0,
AreaName varchar(500) default '',
Area_FirstTotal float default 0,
Area_SecondTotal float default 0,
Area_DMA float default 0,
Area_FToS_Min float default 0,
Area_FToS_Rate varchar(100) default '',
Area_SToT_Min float default 0,
Area_SToT_Rate varchar(100) default '',
ReportTime varchar(100) default ''
)
AS
BEGIN
DECLARE @AreaFlow TABLE
(
AreaID int default 0,
AreaName varchar(500) default '',
UpID int default 0,
TopID int default 0,
Flow float default 0
)

INSERT @AreaFlow(b.AreaID,Flow,AreaName)
SELECT b.AreaID,SUM(a.PCumulativeFlow),(SELECT cMonitorAreaName FROM DMA_Area WHERE DMA_Area.AreaID =b.AreaID) 
FROM DMA_FlowStaticHour a
RIGHT JOIN DMA_MeterInfo b ON a.DataPointID=b.DataPointID AND b.Area_DataPoint_Type=0
WHERE 
DATEDIFF(MM,a.CaclDate, @Date) =0
GROUP BY b.AreaID

UPDATE @AreaFlow SET
UpID=b.PAreaID
FROM @AreaFlow a, DMA_Area b
WHERE a.AreaID=b.AreaID

UPDATE @AreaFlow SET
TopID=b.PAreaID
FROM @AreaFlow a, DMA_Area b
WHERE a.UpID=b.AreaID

INSERT INTO @T(rows_No, AreaID,UpID,TopID,AreaName,Area_FirstTotal)
SELECT ROW_NUMBER() OVER( ORDER BY TopID, UpID, AreaID), AreaID,UpID,TopID,AreaName,Flow FROM @AreaFlow  WHERE TopID = 0 AND UpID =0

UPDATE @T SET
Area_SecondTotal =ISNULL(( SELECT  SUM(Flow) FROM @AreaFlow WHERE UpID=[@T].AreaID ),0),
Area_DMA  =ISNULL(( SELECT  SUM(Flow) FROM @AreaFlow WHERE TopID=[@T].AreaID ),0)
FROM @T 

INSERT INTO @T (rows_No , AreaName,Area_FirstTotal,Area_SecondTotal,Area_DMA)
SELECT 999999999,'合计',SUM(Area_FirstTotal),SUM(Area_SecondTotal),SUM(Area_DMA)
FROM @T


UPDATE @T SET
Area_FToS_Min=Area_FirstTotal - Area_SecondTotal,
Area_SToT_Min=Area_SecondTotal-Area_DMA

UPDATE @T SET
Area_FToS_Rate=CASE WHEN Area_FirstTotal<> 0 THEN CONVERT(varchar(100),ROUND((Area_SecondTotal)/Area_FirstTotal,4)*100)+'%' 
      WHEN (Area_SecondTotal)<>0 AND Area_FirstTotal<=0 THEN   '-100%'    ELSE '' END ,
Area_SToT_Rate=CASE WHEN Area_SecondTotal<> 0 THEN CONVERT(varchar(100),ROUND((Area_DMA)/Area_SecondTotal,4)*100)+'%' 
      WHEN (Area_DMA)<>0 AND Area_SecondTotal<=0 THEN   '-100%'    ELSE '' END

UPDATE @T SET 
ReportTime = CONVERT(varchar(100), YEAR(@Date)) +'-'+ CONVERT(varchar(100), MONTH(@Date))

RETURN
END
GO

