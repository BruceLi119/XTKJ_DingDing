
CREATE VIEW [dbo].[V_OT_Assets]
AS
SELECT     a.OTID, a.OTNO, a.DepID, a.OTName, a.LocationID,f.Name, a.OTState, a.OTTypeID, a.OTBTypeID, a.OTSTypeID, a.OTUseYear, a.OriginalPrice, a.UserID, a.Created, 
                      a.UserName, b.cDepName, c.CatName AS BCatName, d.CatName AS SCatName, e.CatName
FROM         dbo.OT_Assets AS a LEFT OUTER JOIN
                      dbo.P_Department AS b ON b.iDeptID = a.DepID LEFT OUTER JOIN
                      dbo.EQ_CateGory AS c ON c.DCID = a.OTBTypeID LEFT OUTER JOIN
                      dbo.EQ_CateGory AS d ON d.DCID = a.OTSTypeID LEFT OUTER JOIN
                      dbo.EQ_CateGory AS e ON e.DCID = a.OTTypeID left outer join
                      dbo.EQ_DeptArea as f on f.ID = a.LocationID

GO

