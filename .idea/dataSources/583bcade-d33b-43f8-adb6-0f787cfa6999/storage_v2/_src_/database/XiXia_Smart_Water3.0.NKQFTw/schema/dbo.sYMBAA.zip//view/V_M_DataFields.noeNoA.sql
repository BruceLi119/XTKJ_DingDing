CREATE VIEW dbo.V_M_DataFields
AS
SELECT     dbo.M_DataFields.iDataFieldID, dbo.M_DataFields.iMoinitorDataTableID, dbo.M_DataFields.iDKID, dbo.M_DataFields.iDataChinaname, 
                      dbo.M_DataFields.iDataFieldName, dbo.M_DataFields.iDataFieldOrder, dbo.M_DataFields.iDataFieldDescribe, dbo.M_DataFields.iCreatedUser, 
                      dbo.M_DataFields.iCreated, dbo.M_MonitorDataTable.cMoinitorDataName, dbo.M_MonitorDataTable.cMoinitorDataTableName, dbo.M_DataKind.iDKName, 
                      dbo.M_DataKind.iDataType, dbo.M_DataFields.iDataAlias, dbo.M_DataFields.iIsBaseField, dbo.M_DataFields.ControlType, dbo.M_DataFields.DataType, 
                      dbo.M_DataFields.DataLength, dbo.M_DataFields.DataValue, dbo.M_DataFields.IsUrl, dbo.M_DataFields.ValueField, dbo.M_DataFields.TextField, 
                      dbo.M_DataKind.iDKUnit
FROM         dbo.M_DataKind RIGHT OUTER JOIN
                      dbo.M_DataFields ON dbo.M_DataKind.iDKID = dbo.M_DataFields.iDKID LEFT OUTER JOIN
                      dbo.M_MonitorDataTable ON dbo.M_DataFields.iMoinitorDataTableID = dbo.M_MonitorDataTable.iMoinitorDataTableID
GO

