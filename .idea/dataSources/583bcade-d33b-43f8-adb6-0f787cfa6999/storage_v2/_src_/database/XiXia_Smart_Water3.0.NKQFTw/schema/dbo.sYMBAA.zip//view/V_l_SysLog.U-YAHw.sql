CREATE VIEW dbo.V_l_SysLog
AS
SELECT     TOP (100) PERCENT iSysLogID, iAdminID, cURL, cIP, dLoginDT, cAdminName,
                          (SELECT     cFunName
                            FROM          dbo.P_Function
                            WHERE      (iFunID = dbo.l_SysLog.iFunctionID)) AS cFunName, iFunctionID
FROM         dbo.l_SysLog
ORDER BY dLoginDT DESC
GO

