CREATE VIEW dbo.V_B_DataPoint
AS
SELECT     a.DataPointID, a.DataPointName, a.iMonitorPointID, a.iMeterTypeID, a.iMeterFactoryID, a.RTUCodeValue, a.iMeterSN, a.iMeterAddress, a.MeterBase, a.MeterVerify, 
                      a.MeterNumber, a.MeterIngType, a.dMeterInstallationDate, a.cInstallationLocation, a.DataFunURL, a.DataMapX, a.DataMapY, b.cMeterType, b.iSampleOveroadFlow, 
                      b.iSampleTransitionaFlow, c.cMeterFactoryName, a.DataPointIsDelete
FROM         dbo.BM_MeterInfo AS a LEFT OUTER JOIN
                      dbo.BM_MeterType AS b ON b.iMeterTypeID = a.iMeterTypeID LEFT OUTER JOIN
                      dbo.BM_MeterFactory AS c ON c.iMeterFactoryID = a.iMeterFactoryID
GO

