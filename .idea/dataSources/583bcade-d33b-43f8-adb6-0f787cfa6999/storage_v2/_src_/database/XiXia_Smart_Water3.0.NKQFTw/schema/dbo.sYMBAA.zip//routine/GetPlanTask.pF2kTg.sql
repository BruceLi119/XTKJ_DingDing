CREATE function [dbo].[GetPlanTask]
(
@PlanID INT
)
RETURNS VARCHAR(100)
AS
BEGIN
DECLARE @Total INT
DECLARE @Finish INT
DECLARE @Cancel INT
DECLARE @Rate FLOAT

SELECT @Total=COUNT(1) 
FROM DMA_LeakCheckTask
WHERE IdPlan=@PlanID

SELECT @Finish=COUNT(1) 
FROM DMA_LeakCheckTask
WHERE IdPlan=@PlanID
AND TaskStatus=3

SELECT @Cancel=COUNT(1) 
FROM DMA_LeakCheckTask
WHERE IdPlan=@PlanID
AND TaskStatus=0

IF @Total>0
SET @Rate= CONVERT(FLOAT,@Finish+@Cancel)/CONVERT(FLOAT,@Total)
ELSE
SET @Rate=0



RETURN @Rate*100
END
GO

