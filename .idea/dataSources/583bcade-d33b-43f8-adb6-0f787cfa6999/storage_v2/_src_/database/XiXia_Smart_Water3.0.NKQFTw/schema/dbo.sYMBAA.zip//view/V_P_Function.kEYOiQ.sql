CREATE VIEW dbo.V_P_Function
AS
SELECT     dbo.P_Function.iFunID, dbo.P_Function.cFunName, dbo.P_Function.cFunUrl, dbo.P_Function.iFunFatherID, P_Function_1.cFunName AS cFunFatherName, 
                      dbo.P_Function.iFunMenuIsShow, dbo.P_Function.System_Type, dbo.P_Function.cFunOnClick, dbo.P_Function.cFunIcon, dbo.P_Function.cFunSmallIcon, 
                      dbo.P_Function.iFunOrder, dbo.P_Function.Type
FROM         dbo.P_Function LEFT OUTER JOIN
                      dbo.P_Function AS P_Function_1 ON dbo.P_Function.iFunFatherID = P_Function_1.iFunID
GO

